package question2;

public class NextGretestNumber {

}
