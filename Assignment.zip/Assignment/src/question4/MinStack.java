package question4;

import entity.Stack;

import java.util.Scanner;

public class MinStack {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Stack stk = new Stack();
        Stack temp = new Stack();
        System.out.print("Enter Size of Stack : ");
        int size = sc.nextInt();
        stk.createStack(size);
        temp.createStack(size);
        int ch = 0;
        do{
            System.out.println("\nStack Menu\n----------------\n1.Push\n2.Pop\n3.Peek\n4.Max Element in Stack\n.Print Stack\n0.Exit\n:");
            ch=sc.nextInt();
            switch (ch){
                case 1:
                    if(!stk.isFull()){
                        System.out.println("Enter data:");
                        int e=sc.nextInt();
                        stk.push(e);
                        if(stk.isEmpty()){
                            temp.push(e);
                        }
                        else{
                            if(temp.peek() < e){
                                temp.push(e);
                            }
                        }
                    }
                    else {
                        System.out.println("Stack is FUll");
                    }
                    break;
                case 2:
                    if(!mainStk.isEmpty()){

                    }
            }
        }while(ch != 0);
    }
}
